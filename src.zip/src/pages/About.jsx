import React from "react";

export default function About() {
  return (
    <>
      <div className="p-10 mt-20">
        <div>About</div>
        <div>About</div>
        <div>About</div>
        <div>About</div>
        <div>About</div>
      </div>
    </>
  );
}
