import React from "react";
import GalleryGrid from "../components/GalleryGrid";
import images from "../data/images";

export default function InstagramPage() {
  return (
    <div className="flex flex-col items-center">
      <GalleryGrid images={images} />
    </div>
  );
}
