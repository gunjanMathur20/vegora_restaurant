import React from "react";
import ProductGrid from "../components/ProductGrid";
import products from "../data/product";

export default function ProductPage() {
  return (
    <div className="flex flex-col items-center mt-15">
      <ProductGrid products={products} />
    </div>
  );
}
