import { FaPlus, FaMinus, FaTrash } from "react-icons/fa";
import { useCart } from "../context/CartContext";
import CartBanner from "../components/CartBanner";

const CartPage = () => {
  const { cartItems, increaseQty, decreaseQty, removeFromCart } = useCart();

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  if (cartItems.length === 0) {
    return (
      <>
        <CartBanner />
        <div className="pt- min-h-[25vh] flex items-center justify-center">
          <h2 className="text-4xl font-semibold text-gray-600">
            Your cart is empty 🛒🛍️🙈
          </h2>
        </div>
      </>
    );
  }

  return (
    <>
      {/* ================= BANNER ================= */}
      <CartBanner />

      {/* ================= CONTENT ================= */}
      <div className="pt-8 bg-gradient-to-b from-gray-50 to-gray-100 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-3 gap-12">

          {/* ================= DESKTOP TABLE ================= */}
          <div className="lg:col-span-2 hidden md:block overflow-x-auto">
            <table className="w-full bg-white rounded-2xl shadow-lg overflow-hidden">
              <thead className="bg-gray-100 text-xs uppercase tracking-widest text-gray-500">
                <tr>
                  <th className="p-5 text-left">Product</th>
                  <th className="p-5">Price</th>
                  <th className="p-5">Quantity</th>
                  <th className="p-5">Total</th>
                  <th className="p-5 text-center">Remove</th>
                </tr>
              </thead>

              <tbody>
                {cartItems.map((item) => (
                  <tr
                    key={item.id}
                    className="border-t hover:bg-red-50/30 transition"
                  >
                    {/* PRODUCT */}
                    <td className="p-5">
                      <div className="flex items-center gap-5">
                        <div className="w-20 h-20 rounded-xl overflow-hidden border bg-gray-50">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <span className="font-semibold">{item.name}</span>
                      </div>
                    </td>

                    {/* PRICE */}
                    <td className="p-5 font-semibold">
                      ${item.price.toFixed(2)}
                    </td>

                    {/* QUANTITY */}
                    <td className="p-5">
                      <div className="inline-flex items-center gap-4 bg-gray-100 px-4 py-2 rounded-full">
                        <button onClick={() => decreaseQty(item.id)}>
                          <FaMinus size={12} />
                        </button>
                        <span className="font-bold">{item.quantity}</span>
                        <button onClick={() => increaseQty(item.id)}>
                          <FaPlus size={12} />
                        </button>
                      </div>
                    </td>

                    {/* TOTAL */}
                    <td className="p-5 font-bold">
                      ${(item.price * item.quantity).toFixed(2)}
                    </td>

                    {/* REMOVE */}
                    <td className="p-5 text-center">
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-gray-400 hover:text-red-600"
                      >
                        <FaTrash />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* ================= MOBILE LAYOUT ================= */}
          <div className="md:hidden space-y-4">
            {cartItems.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl shadow p-4 space-y-3"
              >
                <h3 className="font-semibold text-lg">{item.name}</h3>

                <div className="flex justify-between text-sm text-gray-600">
                  <span>Price</span>
                  <span>${item.price.toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Quantity</span>

                  <div className="inline-flex items-center gap-4 bg-gray-100 px-4 py-2 rounded-full">
                    <button onClick={() => decreaseQty(item.id)}>
                      <FaMinus size={12} />
                    </button>
                    <span className="font-bold">{item.quantity}</span>
                    <button onClick={() => increaseQty(item.id)}>
                      <FaPlus size={12} />
                    </button>
                  </div>
                </div>

                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span>
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                </div>

                <button
                  onClick={() => removeFromCart(item.id)}
                  className="text-red-500 text-sm flex items-center gap-2"
                >
                  <FaTrash /> Remove
                </button>
              </div>
            ))}
          </div>

          {/* ================= SUMMARY ================= */}
          <div className="bg-white/80 backdrop-blur p-8 rounded-2xl shadow-xl h-fit sticky top-36">
            <h2 className="text-2xl font-semibold mb-8">Order Summary</h2>

            <div className="flex justify-between mb-5">
              <span>Subtotal</span>
              <span className="font-semibold">
                ${subtotal.toFixed(2)}
              </span>
            </div>

            <div className="border-t pt-6 flex justify-between text-lg font-bold">
              <span>Total</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>

            <button className="w-full mt-8 bg-red-500 text-white py-4 rounded-xl text-lg hover:bg-red-600 transition">
              Proceed to Checkout
            </button>
          </div>

        </div>
      </div>
    </>
  );
};

export default CartPage;
