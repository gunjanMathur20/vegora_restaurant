import { motion } from "framer-motion";
import { HiX } from "react-icons/hi";
import { FaBurger } from "react-icons/fa6";

export default function Login({ onClose, onRegisterOpen }) {
  return (
    <div className="fixed inset-0 z-50 flex">

      {/* BACKDROP */}
      <div
        className="flex-1"
        onClick={onClose}
      ></div>

      {/* PANEL */}
      <motion.div
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ duration: 0.45, ease: "easeOut" }}
        className="w-full max-w-md h-screen bg-white shadow-xl p-6 relative"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-600 text-2xl cursor-pointer"
        >
          <HiX />
        </button>

        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mt-10">
          <span className="text-red-600">
            <FaBurger size={35} />
          </span>
          <h1 className="text-4xl font-bold text-red-500">Foodry</h1>
        </div>

        <h2 className="text-center text-xl font-semibold text-gray-800 mt-4">
          Great to have you back!
        </h2>

        {/* Email */}
        <div className="mt-6">
          <label className="block mb-1 text-gray-600">Email Address</label>
          <input
            type="email"
            className="w-full px-4 py-3 shadow rounded-lg outline-none focus:ring-2 focus:ring-red-400 text-black"
            placeholder="Enter your email"
          />
        </div>

        {/* Password */}
        <div className="mt-4">
          <label className="block mb-1 text-gray-600">Password</label>
          <input
            type="password"
            className="w-full px-4 py-3 shadow rounded-lg outline-none focus:ring-2 focus:ring-red-400 text-black"
            placeholder="Enter your password"
            
          />
        </div>

        <div className="text-right mt-2">
          <p className="text-sm text-gray-500 hover:text-red-500 cursor-pointer">
            Forgot your password?
          </p>
        </div>

        <button className="w-full py-3 bg-black text-white rounded-lg font-semibold text-lg hover:bg-gray-800 transition mt-6 cursor-pointer">
          LOG IN
        </button>

        <p className="text-center text-gray-500 text-sm mt-4">
          Don’t have an account?{" "}
          <span
            className="text-red-500 font-medium hover:underline cursor-pointer"
            onClick={onRegisterOpen}
          >
            Register now
          </span>
        </p>
      </motion.div>
    </div>
  );
}
