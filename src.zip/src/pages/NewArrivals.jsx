import ProductCard from "../components/ArrivalProducts";
import products from "../data/product";

export default function NewArrivals() {
  return (
    <section className="py-16">
      <div className="container mx-auto px-6">
        {/* SECTION TITLE */}
        <h2 className="text-2xl md:text-5xl font-bold text-center mb-12">
          New Arrivals
        </h2>

        {/* PRODUCTS GRID */}
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
