import { useWishlist } from "../context/AddToWishlist";
import { FaTrash } from "react-icons/fa";

export default function WishlistPage() {
  const { wishlistItems, toggleWishlist } = useWishlist();

  if (!wishlistItems.length) {
    return (
      <div className="pt-32 min-h-[60vh] flex flex-col items-center justify-center text-center px-4 overflow-x-hidden">
        <h2 className="text-2xl md:text-3xl font-semibold text-gray-700">
          Your wishlist is empty ❤️
        </h2>
        <p className="mt-3 text-gray-500 text-sm md:text-base">
          Start adding products you love
        </p>
      </div>
    );
  }

  return (
    <div className="pt-28 md:pt-32 max-w-7xl mx-auto px-4 overflow-x-hidden">
      <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">
        My Wishlist
      </h2>

      {/* GRID */}
      <div
        className="
          grid gap-4
          grid-cols-1
          sm:grid-cols-2
          md:grid-cols-3
          lg:grid-cols-4
          w-full
        "
      >
        {wishlistItems.map((item) => (
          <div
            key={item.id}
            className="
              bg-white rounded-2xl shadow-sm
              hover:shadow-lg transition-all
              flex flex-col
              w-full
              overflow-hidden
            "
          >
            {/* IMAGE */}
            <div className="h-52 w-full flex items-center justify-center bg-gray-50">
              <img
                src={item.image}
                alt={item.name}
                className="
                  max-h-[180px]
                  max-w-full
                  object-contain
                "
              />
            </div>

            {/* CONTENT */}
            <div className="p-4 flex flex-col flex-1">
              <h3 className="font-semibold text-center text-gray-800">
                {item.name}
              </h3>

              <p className="text-center text-red-500 font-bold mt-1">
                ${item.price}
              </p>

              <button
                onClick={() => toggleWishlist(item)}
                className="
                  mt-4
                  w-full
                  flex items-center justify-center gap-2
                  text-sm font-medium
                  text-red-500
                  border border-red-200
                  py-2 rounded-lg
                  hover:bg-red-500 hover:text-white
                  transition-all
                "
              >
                <FaTrash size={14} />
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
