import { FaShippingFast, FaHeadset } from "react-icons/fa";
import { GoPackageDependencies } from "react-icons/go";
import { MdSupportAgent } from "react-icons/md";

export default function Features() {
  return (
    <section className="bg-white py-20">
      <div className="container mx-auto px-6">
        <div className="grid gap-10 md:grid-cols-3">

          {/* CARD 1 */}
          <div className="group text-center p-8 rounded-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-lg">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-black text-white transition group-hover:scale-110">
              <FaShippingFast className="text-4xl" />
            </div>
            <h3 className="text-sm font-semibold tracking-widest mb-3">
              SHIPPING & RETURN
            </h3>
            <p className="text-sm text-gray-600 leading-relaxed max-w-xs mx-auto">
              If your glasses aren't perfect, return them within 30 days for a
              full refund. We'll even pay shipping.
            </p>
          </div>

          {/* CARD 2 (NO BORDERS NOW) */}
          <div className="group text-center p-8 rounded-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-lg">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-black text-white transition group-hover:scale-110">
              <GoPackageDependencies className="text-4xl" />
            </div>
            <h3 className="text-sm font-semibold tracking-widest mb-3">
              SAFE PAYMENT
            </h3>
            <p className="text-sm text-gray-600 leading-relaxed max-w-xs mx-auto">
              Pay with the world's most popular and secure payment methods.
            </p>
          </div>

          {/* CARD 3 */}
          <div className="group text-center p-8 rounded-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-lg">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-black text-white transition group-hover:scale-110">
              <MdSupportAgent className="text-4xl" />
            </div>
            <h3 className="text-sm font-semibold tracking-widest mb-3">
              SHOP WITH CONFIDENCE
            </h3>
            <p className="text-sm text-gray-600 leading-relaxed max-w-xs mx-auto">
              Our Buyer Protection covers your purchase from click to delivery.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
}
