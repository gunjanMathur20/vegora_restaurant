// import { FaPlus, FaMinus, FaTrash } from "react-icons/fa";
// import { useCart } from "../context/CartContext";

// const CartItem = ({ item }) => {
//   const { increaseQty, decreaseQty, removeFromCart } = useCart();

//   return (
//     <div className="flex flex-col sm:flex-row items-center gap-4 bg-white p-4 rounded-xl shadow-sm">
//       <img
//         src={item.image}
//         alt={item.name}
//         className="w-24 h-24 rounded-lg object-cover"
//       />

//       <div className="flex-1 w-full">
//         <h2 className="font-medium text-lg">{item.name}</h2>
//         <p className="text-gray-500">${item.price}</p>

//         <div className="flex items-center gap-3 mt-4">
//           <button
//             onClick={() => decreaseQty(item.id)}
//             className="p-2 border rounded-lg"
//           >
//             <FaMinus size={12} />
//           </button>

//           <span>{item.quantity}</span>

//           <button
//             onClick={() => increaseQty(item.id)}
//             className="p-2 border rounded-lg"
//           >
//             <FaPlus size={12} />
//           </button>
//         </div>
//       </div>

//       <div className="flex sm:flex-col items-center gap-4">
//         <p className="font-semibold">
//           ${(item.price * item.quantity).toFixed(2)}
//         </p>
//         <button
//           onClick={() => removeFromCart(item.id)}
//           className="text-red-500"
//         >
//           <FaTrash />
//         </button>
//       </div>
//     </div>
//   );
// };

// export default CartItem;

// ===================================================
// import { FaPlus, FaMinus, FaTrash } from "react-icons/fa";
// import { useCart } from "../context/CartContext";

// const CartItem = ({ item }) => {
//   const { increaseQty, decreaseQty, removeFromCart } = useCart();

//   return (
//     <div className="flex gap-4 bg-white p-4 rounded-xl">
//       <img src={item.image} className="w-24 h-24" />

//       <div className="flex-1">
//         <h2>{item.name}</h2>
//         <p>${item.price}</p>

//         <div className="flex gap-3 mt-3">
//           <button onClick={() => decreaseQty(item.id)}>
//             <FaMinus />
//           </button>
//           <span>{item.quantity}</span>
//           <button onClick={() => increaseQty(item.id)}>
//             <FaPlus />
//           </button>
//         </div>
//       </div>

//       <div>
//         ${(item.price * item.quantity).toFixed(2)}
//         <button onClick={() => removeFromCart(item.id)}>
//           <FaTrash />
//         </button>
//       </div>
//     </div>
//   );
// };

// export default CartItem;

// ================================================

// import { FaPlus, FaMinus, FaTrash } from "react-icons/fa";
// import { useCart } from "../context/CartContext";

// export default function CartItem({ item }) {
//   const { increaseQty, decreaseQty, removeFromCart } = useCart();

//   return (
//     <div className="grid grid-cols-5 items-center border-b py-4">
//       <div className="flex items-center gap-4">
//         <img src={item.image} className="w-20" />
//         <span>{item.name}</span>
//       </div>

//       <span>${item.price}</span>

//       <div className="flex items-center border w-max">
//         <button onClick={() => decreaseQty(item.id)} className="px-2">
//           -
//         </button>
//         <span className="px-3">{item.quantity}</span>
//         <button onClick={() => increaseQty(item.id)} className="px-2">
//           +
//         </button>
//       </div>

//       <span>${(item.price * item.quantity).toFixed(2)}</span>

//       <button onClick={() => removeFromCart(item.id)}>
//         <FaTrash />
//       </button>
//     </div>
//   );
// }

// ================================================

import { FaPlus, FaMinus, FaTrash } from "react-icons/fa";
import { useCart } from "../context/CartContext";

const CartItem = ({ item }) => {
  const { increaseQty, decreaseQty, removeFromCart } = useCart();

  return (
    <div className="flex gap-4 bg-white p-4 rounded-xl">
      <img src={item.image} className="w-24 h-24 object-cover" />

      <div className="flex-1">
        <h2>{item.name}</h2>
        <p>${item.price}</p>

        <div className="flex gap-3 mt-3">
          <button onClick={() => decreaseQty(item.id)}>
            <FaMinus />
          </button>
          <span>{item.quantity}</span>
          <button onClick={() => increaseQty(item.id)}>
            <FaPlus />
          </button>
        </div>
      </div>

      <div className="flex flex-col items-end gap-2">
        ${(item.price * item.quantity).toFixed(2)}
        <button onClick={() => removeFromCart(item.id)}>
          <FaTrash />
        </button>
      </div>
    </div>
  );
};

export default CartItem;
