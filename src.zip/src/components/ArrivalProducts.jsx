// import { FiHeart, FiShoppingBag, FiSearch } from "react-icons/fi";
// import Countdown from "./Countdown";

// export default function ArrivalProducts({ product }) {
//   return (
//     <div className="group relative">
//       {/* IMAGE WRAPPER */}
//       <div className="relative w-full h-[300px] flex items-center justify-center overflow-hidden">
//         {/* SALE */}
//         {product.sale && (
//           <span className="absolute top-4 right-10 bg-red-500 text-white text-xs px-3 py-1 z-10">
//             SALE
//           </span>
//         )}

//         {/* IMAGE */}
//         <img
//           src={product.image}
//           alt={product.name}
//           className="object-contain transition-transform duration-700 ease-out group-hover:scale-110"
//           style={{ width: 300, height: 280 }}
//         />

//         {/* ICONS */}
//         <div className="absolute inset-0 flex items-center justify-center">
//           <div className="flex gap-4 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500 z-10">
//             {[FiShoppingBag, FiSearch, FiHeart].map((Icon, i) => (
//               <button
//                 key={i}
//                 className="bg-white w-11 h-11 rounded-full flex items-center justify-center shadow-md hover:bg-black hover:text-white transition cursor-pointer"
//               >
//                 <Icon />
//               </button>
//             ))}
//           </div>
//         </div>

//         {/* COUNTDOWN */}
//         {product.dealEnd && (
//           <Countdown targetDate={product.dealEnd} className="bottom-4" />
//         )}
//       </div>

//       {/* CONTENT */}
//       <div className="mt-4 text-center">
//         <h3 className="font-medium mb-1">{product.name}</h3>

//         <p className="text-red-500 font-semibold">
//           ${product.price}
//           {product.oldPrice && (
//             <span className="line-through text-gray-400 text-sm ml-2">
//               ${product.oldPrice}
//             </span>
//           )}
//         </p>
//       </div>
//     </div>
//   );
// }

// ====================================================
// import { FiHeart, FiShoppingBag, FiSearch } from "react-icons/fi";
// import { useCart } from "../context/CartContext";
// import Countdown from "./Countdown";

// export default function ArrivalProducts({ product }) {
//   const { addToCart } = useCart();

//   return (
//     <div className="group relative">
//       <div className="relative w-full h-[300px] flex items-center justify-center overflow-hidden">
//         {product.sale && (
//           <span className="absolute top-4 right-10 bg-red-500 text-white text-xs px-3 py-1 z-10">
//             SALE
//           </span>
//         )}

//         <img
//           src={product.image}
//           alt={product.name}
//           className="object-contain transition-transform duration-700 group-hover:scale-110"
//           style={{ width: 300, height: 280 }}
//         />

//         <div className="absolute inset-0 flex items-center justify-center">
//           <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition-all">
//             <button
//               className="bg-white w-11 h-11 rounded-full flex items-center justify-center shadow-md"
//               onClick={(e) => {
//                 e.stopPropagation();
//                 addToCart(product);
//               }}
//             >
//               <FiShoppingBag />
//             </button>

//             <button className="bg-white w-11 h-11 rounded-full flex items-center justify-center shadow-md">
//               <FiSearch />
//             </button>

//             <button className="bg-white w-11 h-11 rounded-full flex items-center justify-center shadow-md">
//               <FiHeart />
//             </button>
//           </div>
//         </div>

//         {product.dealEnd && <Countdown targetDate={product.dealEnd} />}
//       </div>

//       <div className="mt-4 text-center">
//         <h3 className="font-medium">{product.name}</h3>
//         <p className="text-red-500 font-semibold">${product.price}</p>
//       </div>
//     </div>
//   );
// }

// ======================================================
// import { FiHeart, FiShoppingBag, FiSearch } from "react-icons/fi";
// import { useCart } from "../context/CartContext";
// import Countdown from "./Countdown";

// export default function ArrivalProducts({ product }) {
//   const { toggleCartItem, isInCart } = useCart();
//   const added = isInCart(product.id);

//   return (
//     <div className="group relative">
//       <div className="relative w-full h-[300px] flex items-center justify-center overflow-hidden">
//         <img
//           src={product.image}
//           alt={product.name}
//           className="object-contain transition-transform duration-700 group-hover:scale-110"
//           style={{ width: 300, height: 280 }}
//         />

//         <div className="absolute inset-0 flex items-center justify-center">
//           <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition-all">
//             {/* CART TOGGLE */}
//             <button
//               onClick={(e) => {
//                 e.stopPropagation();
//                 toggleCartItem(product);
//               }}
//               className={`bg-white w-11 h-11 rounded-full flex items-center justify-center shadow-md
//                 ${added ? "text-red-500" : ""}`}
//             >
//               <FiShoppingBag />
//             </button>

//             <button className="bg-white w-11 h-11 rounded-full flex items-center justify-center shadow-md">
//               <FiSearch />
//             </button>

//             <button className="bg-white w-11 h-11 rounded-full flex items-center justify-center shadow-md">
//               <FiHeart />
//             </button>
//           </div>
//         </div>

//         {product.dealEnd && <Countdown targetDate={product.dealEnd} />}
//       </div>

//       <div className="mt-4 text-center">
//         <h3 className="font-medium">{product.name}</h3>
//         <p className="text-red-500 font-semibold">${product.price}</p>
//       </div>
//     </div>
//   );
// }

// =====================================

// import { FiHeart, FiShoppingBag, FiSearch } from "react-icons/fi";
// import { useCart } from "../context/CartContext";
// import { useWishlist } from "../context/AddToWishlist";

// export default function ArrivalProducts({ product }) {
//   const { toggleCartItem, isInCart } = useCart();
//   const { toggleWishlist, isInWishlist } = useWishlist();

//   return (
//     <div className="group relative">
//       <div className="relative h-[300px] flex items-center justify-center overflow-hidden">
//         <img
//           src={product.image}
//           alt={product.name}
//           className="object-contain transition-transform duration-500 group-hover:scale-110"
//           style={{ width: 300, height: 280 }}
//         />

//         <div className="absolute inset-0 flex items-center justify-center">
//           <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition">
            
//             {/* CART */}
//             <button
//               onClick={() => toggleCartItem(product)}
//               className={`bg-white w-11 h-11 rounded-full shadow
//               flex items-center justify-center
//               ${isInCart(product.id) ? "text-red-500" : ""}`}
//             >
//               <FiShoppingBag />
//             </button>

//             {/* SEARCH */}
//             <button
//               className="bg-white w-11 h-11 rounded-full shadow
//               flex items-center justify-center"
//             >
//               <FiSearch />
//             </button>

//             {/* WISHLIST */}
//             <button
//               onClick={() => toggleWishlist(product)}
//               className={`bg-white w-11 h-11 rounded-full shadow
//               flex items-center justify-center
//               ${isInWishlist(product.id) ? "text-red-500" : ""}`}
//             >
//               <FiHeart />
//             </button>

//           </div>
//         </div>
//       </div>

//       <div className="text-center mt-4">
//         <h3 className="font-medium">{product.name}</h3>
//         <p className="text-red-500 font-semibold">${product.price}</p>
//       </div>
//     </div>
//   );
// }
// ================================

import { FiHeart, FiShoppingBag, FiSearch } from "react-icons/fi";
import { useCart } from "../context/CartContext";
import { useWishlist } from "../context/AddToWishlist";

export default function ArrivalProducts({ product }) {
  const { toggleCartItem, isInCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  return (
    <div className="group relative">
      <div className="relative h-[300px] flex items-center justify-center overflow-hidden">

        {/* IMAGE */}
        <img
          src={product.image}
          alt={product.name}
          className="object-contain transition-transform duration-500 group-hover:scale-110"
          style={{ width: 300, height: 280 }}
        />

        {/* ================= DESKTOP ICONS (UNCHANGED) ================= */}
        <div className="absolute inset-0 items-center justify-center hidden md:flex">
          <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition">
            <button
              onClick={() => toggleCartItem(product)}
              className={`bg-white w-13 h-13 rounded-full shadow flex items-center justify-center transition-transform duration-200 ease-out hover:scale-110
              ${isInCart(product.id) ? "text-red-500" : ""}`}
            >
              <FiShoppingBag />
            </button>

            {/* <button className="bg-white w-11 h-11 rounded-full shadow flex items-center justify-center">
              <FiSearch />
            </button> */}

            <button
              onClick={() => toggleWishlist(product)}
              className={`bg-white w-13 h-13 rounded-full shadow flex items-center justify-center transition-transform duration-200 ease-out hover:scale-110
              ${isInWishlist(product.id) ? "text-red-500" : ""}`}
            >
              <FiHeart />
            </button>
          </div>
        </div>

        {/* ================= MOBILE / TABLET BOTTOM ICONS ================= */}
        <div className="absolute bottom-3 left-0 w-full flex justify-center gap-6 md:hidden">
          <button
            onClick={() => toggleCartItem(product)}
            className={`bg-white w-12 h-12 rounded-full shadow flex items-center justify-center
            ${isInCart(product.id) ? "text-red-500" : ""}`}
          >
            <FiShoppingBag />
          </button>

          <button
            onClick={() => toggleWishlist(product)}
            className={`bg-white w-12 h-12 rounded-full shadow flex items-center justify-center
            ${isInWishlist(product.id) ? "text-red-500" : ""}`}
          >
            <FiHeart />
          </button>
        </div>
      </div>

      {/* CONTENT */}
      <div className="text-center mt-4">
        <h3 className="font-medium">{product.name}</h3>
        <p className="text-red-500 font-semibold">${product.price}</p>
      </div>
    </div>
  );
}

