// import React, { useState } from "react";
// import { FaHeart, FaSearch, FaShoppingBag } from "react-icons/fa";

// export default function ProductCard({ item }) {
//   const [hover, setHover] = useState(false);

//   return (
//     <div
//       className="relative bg-white rounded-xl p-4 hover:shadow-xl transition-all duration-300"
//       onMouseEnter={() => setHover(true)}
//       onMouseLeave={() => setHover(false)}
//     >
//       {/* Image Box */}
//       <div className="relative w-full h-75 flex items-center justify-center overflow-hidden">
//         {/* Discount Label */}
//         {item.discount && (
//           <span className="absolute top-4 left-4 bg-red-600 text-white text-xs font-semibold px-2 py-1 rounded">
//             -{item.discount}%
//           </span>
//         )}

//         {/* Product Image */}
//         <img
//           src={item.image}
//           alt={item.name}
//           className={`object-contain transition-all duration-700 ease-out ${
//             hover ? "scale-110" : "scale-100"
//           }`}
//           style={{ width: 300, height: 300 }}
//         />

//         {/* Smooth Overlay */}
//         <div
//           className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-all duration-500 ease-out ${
//             hover ? "opacity-100" : "opacity-0"
//           }`}
//         >
//           <div
//             className={`flex gap-4 transition-all duration-500 ${
//               hover ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
//             }`}
//           >
//             {/* Add to Cart */}
//             <button className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-md hover:bg-gray-100 transition-all duration-300">
//               <FaShoppingBag className="text-gray-800 text-xl" />
//             </button>

//             {/* Quick View */}
//             <button className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-md hover:bg-gray-100 transition-all duration-300">
//               <FaSearch className="text-gray-800 text-xl" />
//             </button>

//             {/* Wishlist */}
//             <button className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-md hover:bg-gray-100 transition-all duration-300">
//               <FaHeart className="text-gray-800 text-xl" />
//             </button>
//           </div>
//         </div>
//       </div>

//       {/* Title */}
//       <h3 className="text-center text-lg font-semibold mt-4">{item.name}</h3>

//       {/* Prices */}
//       <div className="text-center mt-2">
//         {item.oldPrice && (
//           <span className="line-through text-gray-500 mr-2">
//             ${item.oldPrice.toFixed(2)}
//           </span>
//         )}
//         <span className="text-red-600 font-bold text-xl">
//           ${item.price.toFixed(2)}
//         </span>
//       </div>
//     </div>
//   );
// }

// ====================================================

// import { useState } from "react";
// import { FaHeart, FaSearch, FaShoppingBag } from "react-icons/fa";
// import { useCart } from "../context/CartContext";

// export default function ProductCard({ item }) {
//   const [hover, setHover] = useState(false);
//   const { addToCart } = useCart();

//   return (
//     <div
//       className="relative bg-white rounded-xl p-4 hover:shadow-xl transition-all duration-300"
//       onMouseEnter={() => setHover(true)}
//       onMouseLeave={() => setHover(false)}
//     >
//       <div className="relative w-full h-75 flex items-center justify-center overflow-hidden">
//         {item.discount && (
//           <span className="absolute top-4 left-4 bg-red-600 text-white text-xs font-semibold px-2 py-1 rounded">
//             -{item.discount}%
//           </span>
//         )}

//         <img
//           src={item.image}
//           alt={item.name}
//           className={`object-contain transition-all duration-700 ${
//             hover ? "scale-110" : "scale-100"
//           }`}
//           style={{ width: 300, height: 300 }}
//         />

//         <div
//           className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-all duration-500 ${
//             hover ? "opacity-100" : "opacity-0"
//           }`}
//         >
//           <div className="flex gap-4">
//             <button
//               className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-md"
//               onClick={(e) => {
//                 e.stopPropagation();
//                 addToCart(item);
//               }}
//             >
//               <FaShoppingBag />
//             </button>

//             <button className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-md">
//               <FaSearch />
//             </button>

//             <button className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-md">
//               <FaHeart />
//             </button>
//           </div>
//         </div>
//       </div>

//       <h3 className="text-center text-lg font-semibold mt-4">{item.name}</h3>

//       <div className="text-center mt-2">
//         {item.oldPrice && (
//           <span className="line-through text-gray-500 mr-2">
//             ${item.oldPrice}
//           </span>
//         )}
//         <span className="text-red-600 font-bold text-xl">${item.price}</span>
//       </div>
//     </div>
//   );
// }

// =====================================

// =======================================================
// import { FaShoppingBag, FaSearch, FaHeart } from "react-icons/fa";
// import { useCart } from "../context/CartContext";

// export default function ProductCard({ item }) {
//   const { addToCart, isInCart } = useCart();
//   const added = isInCart(item.id);

//   return (
//     <div className="relative bg-white p-4 rounded-xl hover:shadow-xl">
//       <img src={item.image} className="mx-auto w-[250px]" />

//       <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition">
//         <div className="flex gap-4">
//           <button
//             onClick={() => addToCart(item)}
//             className={`w-12 h-12 bg-white rounded-full flex items-center justify-center ${
//               added ? "text-red-500" : ""
//             }`}
//           >
//             <FaShoppingBag />
//           </button>

//           <button className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
//             <FaSearch />
//           </button>

//           <button className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
//             <FaHeart />
//           </button>
//         </div>
//       </div>

//       <h3 className="text-center mt-4">{item.name}</h3>
//       <p className="text-center text-red-500 font-bold">${item.price}</p>
//     </div>
//   );
// }

// =====================================================

// import { FaHeart, FaSearch, FaShoppingBag } from "react-icons/fa";
// import { useCart } from "../context/CartContext";

// export default function ProductCard({ item }) {
//   const { toggleCart, isInCart } = useCart();
//   const added = isInCart(item.id);

//   return (
//     <div className="relative bg-white rounded-xl p-4 hover:shadow-xl">
//       <img src={item.image} className="mx-auto w-[250px]" />

//       <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition">
//         <div className="flex gap-4">
//           <button
//             onClick={(e) => {
//               e.stopPropagation();
//               toggleCart(item);
//             }}
//             className={`w-12 h-12 bg-white rounded-full flex items-center justify-center
//               ${added ? "text-red-500" : ""}`}
//           >
//             <FaShoppingBag />
//           </button>

//           <button className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
//             <FaSearch />
//           </button>

//           <button className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
//             <FaHeart />
//           </button>
//         </div>
//       </div>

//       <h3 className="text-center mt-4">{item.name}</h3>
//       <p className="text-center text-red-500 font-bold">${item.price}</p>
//     </div>
//   );
// }
// =============================================

// import { FaHeart, FaSearch, FaShoppingBag } from "react-icons/fa";
// import { useCart } from "../context/CartContext";

// export default function ProductCard({ item }) {
//   const { toggleCartItem, isInCart } = useCart();

//   return (
//     <div className="group relative bg-white p-4 rounded-xl">
//       {/* IMAGE */}
//       <div className="relative w-full h-[300px] flex items-center justify-center overflow-hidden">
//         <img
//           src={item.image}
//           alt={item.name}
//           className="object-contain transition-transform duration-500 group-hover:scale-110"
//           style={{ width: 280, height: 280 }}
//         />

//         {/* ICONS */}
//         <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
//           <div className="flex gap-4">
//             {/* CART (SAME AS NEW ARRIVALS) */}
//             <button
//               onClick={(e) => {
//                 e.stopPropagation();
//                 toggleCartItem(item);
//               }}
//               className={`w-12 h-12 rounded-full flex items-center justify-center shadow-md transition
//                 ${
//                   isInCart(item.id)
//                     ? "bg-red-500 text-white"
//                     : "bg-white text-black"
//                 }`}
//             >
//               <FaShoppingBag />
//             </button>

//             {/* SEARCH */}
//             <button className="bg-white w-12 h-12 rounded-full shadow-md flex items-center justify-center transition hover:text-red-500">
//               <FaSearch />
//             </button>

//             {/* WISHLIST (UNCHANGED) */}
//             <button className="bg-white w-12 h-12 rounded-full shadow-md flex items-center justify-center transition hover:text-red-500">
//               <FaHeart />
//             </button>
//           </div>
//         </div>
//       </div>

//       {/* CONTENT */}
//       <h3 className="text-center mt-4 font-semibold">{item.name}</h3>
//       <p className="text-center text-red-600 font-bold">${item.price}</p>
//     </div>
//   );
// }
// =================================

// import { FaHeart, FaSearch, FaShoppingBag } from "react-icons/fa";
// import { useCart } from "../context/CartContext";
// import { useWishlist } from "../context/AddToWishlist";

// export default function ProductCard({ item }) {
//   const { toggleCartItem, isInCart } = useCart();
//   const { toggleWishlist, isInWishlist } = useWishlist();

//   return (
//     <div className="group relative bg-white p-4 rounded-xl">
//       <div className="relative h-[300px] flex items-center justify-center overflow-hidden">
//         <img
//           src={item.image}
//           alt={item.name}
//           className="object-contain transition-transform duration-500 group-hover:scale-110"
//           style={{ width: 280, height: 280 }}
//         />

//         <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
//           <div className="flex gap-4">
//             <button
//               onClick={() => toggleCartItem(item)}
//               className={`w-12 h-12 rounded-full shadow flex items-center justify-center
//               ${isInCart(item.id) ? "bg-red-500 text-white" : "bg-white"}`}
//             >
//               <FaShoppingBag />
//             </button>

//             <button className="w-12 h-12 bg-white rounded-full shadow flex items-center justify-center">
//               <FaSearch />
//             </button>

//             <button
//               onClick={() => toggleWishlist(item)}
//               className={`w-12 h-12 rounded-full shadow flex items-center justify-center
//               ${isInWishlist(item.id) ? "bg-red-500 text-white" : "bg-white"}`}
//             >
//               <FaHeart />
//             </button>
//           </div>
//         </div>
//       </div>

//       <h3 className="mt-4 text-center font-semibold">{item.name}</h3>
//       <p className="text-center text-red-600 font-bold">${item.price}</p>
//     </div>
//   );
// }

// =====================================================

import { FaHeart, FaSearch, FaShoppingBag } from "react-icons/fa";
import { useCart } from "../context/CartContext";
import { useWishlist } from "../context/AddToWishlist";

export default function ProductCard({ item }) {
  const { toggleCartItem, isInCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  return (
    <div className="group relative bg-white p-4 rounded-xl">
      <div className="relative h-[300px] flex items-center justify-center overflow-hidden">
        {/* IMAGE */}
        <img
          src={item.image}
          alt={item.name}
          className="object-contain transition-transform duration-500 group-hover:scale-110"
          style={{ width: 280, height: 280 }}
        />

        {/* ================= DESKTOP ICONS ================= */}
        <div className="absolute inset-0 hidden md:flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
          <div className="flex gap-4">
            <button
              onClick={() => toggleCartItem(item)}
              className={`w-13 h-13 rounded-full shadow flex items-center justify-center transition-transform duration-200 ease-out hover:scale-110
              ${isInCart(item.id) ? "bg-red-500 text-white" : "bg-white"}`}
            >
              <FaShoppingBag />
            </button>

            {/* <button className="w-12 h-12 bg-white rounded-full shadow flex items-center justify-center">
              <FaSearch />
            </button> */}

            <button
              onClick={() => toggleWishlist(item)}
              className={`w-13 h-13 rounded-full shadow flex items-center justify-center  transition-transform duration-200 ease-out hover:scale-110
              ${isInWishlist(item.id) ? "bg-red-500 text-white" : "bg-white"}`}
            >
              <FaHeart />
            </button>
          </div>
        </div>

        {/* ================= MOBILE / TABLET BOTTOM ICONS ================= */}
        <div className="absolute bottom-3 left-0 w-full flex justify-center gap-6 md:hidden">
          <button
            onClick={() => toggleCartItem(item)}
            className={`w-12 h-12 rounded-full shadow flex items-center justify-center
            ${isInCart(item.id) ? "bg-red-500 text-white" : "bg-white"}`}
          >
            <FaShoppingBag />
          </button>

          <button
            onClick={() => toggleWishlist(item)}
            className={`w-12 h-12 rounded-full shadow flex items-center justify-center
            ${isInWishlist(item.id) ? "bg-red-500 text-white" : "bg-white"}`}
          >
            <FaHeart />
          </button>
        </div>
      </div>

      <h3 className="mt-4 text-center font-semibold">{item.name}</h3>
      <p className="text-center text-red-600 font-bold">${item.price}</p>
    </div>
  );
}
