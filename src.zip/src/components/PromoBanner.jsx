import promo1 from "../assets/promoImage01.webp";
import promo2 from "../assets/promoImage02.webp";

export default function PromoBanners() {
  return (
    <div className="container mx-auto px-6">
      <div className="grid gap-8 md:grid-cols-2">

        {/* LEFT PROMO */}
        <div className="relative overflow-hidden group h-100">
          
          {/* IMAGE */}
          <img
            src={promo1}
            alt="Burger Combo"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />

          {/* DARK OVERLAY */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition duration-500"></div>

          {/* TEXT */}
          <div className="absolute inset-0 z-10 flex flex-col justify-center pl-10">
            <h2 className="text-4xl font-semibold mb-4 text-black">
              Good price combos
            </h2>

            <button className="w-fit border border-gray-200 bg-gray-200 shadow-xl px-7 py-2 text-sm font-semibold tracking-widest 
            text-black hover:bg-white hover:text-black transition cursor-pointer">
              SHOP NOW
            </button>
          </div>
        </div>

        {/* RIGHT PROMO */}
        <div className="relative overflow-hidden  group h-100">
          
          <img
            src={promo2}
            alt="Pizza Collection"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />

          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition duration-500"></div>

          <div className="absolute inset-0 z-10 flex flex-col justify-center pl-10">
            <h2 className="text-4xl font-semibold mb-4 text-black">
              Collection Pizza
            </h2>

            <button className="w-fit border border-gray-200 bg-gray-200 shadow-xl px-7 py-2 text-sm font-semibold tracking-widest 
            text-black hover:bg-white hover:text-black transition cursor-pointer">
              SHOP NOW
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
