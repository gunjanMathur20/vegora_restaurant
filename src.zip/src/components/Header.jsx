// import { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
// import { motion, AnimatePresence } from "framer-motion";

// import { FaBurger } from "react-icons/fa6";
// import { CiUser, CiSearch, CiHeart, CiShoppingBasket } from "react-icons/ci";
// import { HiMenu, HiX } from "react-icons/hi";

// import Login from "../pages/Login";
// import Register from "../pages/Register";

// export default function Header() {
//   const [open, setOpen] = useState(false);
//   const [loginOpen, setLoginOpen] = useState(false);
//   const [registerOpen, setRegisterOpen] = useState(false);
//   const [scrolled, setScrolled] = useState(false);

//   useEffect(() => {
//     const handleScroll = () => {
//       setScrolled(window.scrollY > 80);
//     };
//     window.addEventListener("scroll", handleScroll);
//     return () => window.removeEventListener("scroll", handleScroll);
//   }, []);

//   return (
//     <motion.header
//       initial={false}
//       animate={{
//         backgroundColor: scrolled ? "rgba(0,0,0,0.85)" : "rgba(0,0,0,0)",
//         backdropFilter: scrolled ? "blur(12px)" : "blur(0px)",
//       }}
//       transition={{ duration: 0.35, ease: "easeInOut" }}
//       className="fixed top-0 left-0 w-full z-50 text-white"
//     >
//       <div className="container mx-auto px-4 py-7 flex items-center justify-between">
//         {/* MOBILE LEFT */}
//         <div className="flex items-center gap-4 md:hidden">
//           <button onClick={() => setOpen(!open)} className="text-2xl">
//             {open ? <HiX /> : <HiMenu />}
//           </button>

//           <div className="flex items-center gap-2 text-2xl font-semibold">
//             <FaBurger />
//             <span className="italic font-extrabold">Foodry</span>
//           </div>
//         </div>

//         {/* DESKTOP NAV */}
//         <nav className="hidden md:flex items-center gap-10 font-semibold">
//           <Link to="/">HOME</Link>
//           <div className="relative">
//             <Link to="/shop">SHOP</Link>
//             <span className="absolute -top-3 left-6 bg-red-600 text-[10px] px-1 py-0.5 rounded-sm">
//               HOT
//             </span>
//           </div>
//           <Link to="/featured">FEATURED</Link>
//           <Link to="/pages">PAGES</Link>
//           <Link to="/blogs">BLOGS</Link>
//         </nav>

//         {/* LOGO */}
//         <div className="hidden md:flex items-center gap-2 text-4xl font-bold">
//           <FaBurger />
//           <span className="font-mono">Foodry</span>
//         </div>

//         {/* RIGHT ICONS */}
//         <div className="hidden md:flex items-center gap-6 text-xl">
//           <CiSearch />
//           <button onClick={() => setLoginOpen(true)}>
//             <CiUser />
//           </button>
//           <CiHeart />
//           <Link to="/cart" className="hover:text-red-500 transition">
//             <CiShoppingBasket />
//           </Link>
//         </div>
//       </div>

//       {/* MOBILE MENU */}
//       {open && (
//         <div className="md:hidden bg-black/90 backdrop-blur-lg pb-4">
//           <nav className="flex flex-col gap-4 px-6 text-sm font-semibold">
//             <Link to="/">HOME</Link>
//             <Link to="/shop">SHOP</Link>
//             <Link to="/featured">FEATURED</Link>
//             <Link to="/pages">PAGES</Link>
//             <Link to="/blogs">BLOGS</Link>
//           </nav>
//         </div>
//       )}

//       {/* LOGIN / REGISTER */}
//       <AnimatePresence>
//         {loginOpen && (
//           <Login
//             onClose={() => setLoginOpen(false)}
//             onRegisterOpen={() => {
//               setLoginOpen(false);
//               setRegisterOpen(true);
//             }}
//           />
//         )}

//         {registerOpen && (
//           <Register
//             onClose={() => setRegisterOpen(false)}
//             onLoginOpen={() => {
//               setRegisterOpen(false);
//               setLoginOpen(true);
//             }}
//           />
//         )}
//       </AnimatePresence>
//     </motion.header>
//   );
// }

// import { useState, useEffect } from "react";
// import { Link, useLocation } from "react-router-dom";
// import { motion, AnimatePresence } from "framer-motion";
// import { useCart } from "../context/CartContext";

// import { FaBurger } from "react-icons/fa6";
// import { CiUser, CiSearch, CiHeart, CiShoppingBasket } from "react-icons/ci";
// import { HiMenu, HiX } from "react-icons/hi";

// import Login from "../pages/Login";
// import Register from "../pages/Register";

// export default function Header() {
//   const [open, setOpen] = useState(false);
//   const [loginOpen, setLoginOpen] = useState(false);
//   const [registerOpen, setRegisterOpen] = useState(false);
//   const [scrolled, setScrolled] = useState(false);

//   const { cartItems } = useCart();

//   const location = useLocation();
//   const forceSolidBg = location.pathname !== "/";

//   useEffect(() => {
//     const handleScroll = () => {
//       setScrolled(window.scrollY > 80);
//     };
//     window.addEventListener("scroll", handleScroll);
//     return () => window.removeEventListener("scroll", handleScroll);
//   }, []);

//   return (
//     <motion.header
//       initial={false}
//       animate={{
//         backgroundColor:
//           scrolled || forceSolidBg ? "rgba(0,0,0,0.85)" : "rgba(0,0,0,0)",
//         backdropFilter: scrolled || forceSolidBg ? "blur(12px)" : "blur(0px)",
//       }}
//       transition={{ duration: 0.35, ease: "easeInOut" }}
//       className="fixed top-0 left-0 w-full z-50 text-white"
//     >
//       <div className="container mx-auto px-4 py-7 flex items-center justify-between">
//         {/* MOBILE LEFT */}
//         <div className="flex items-center gap-4 md:hidden">
//           <button onClick={() => setOpen(!open)} className="text-2xl">
//             {open ? <HiX /> : <HiMenu />}
//           </button>

//           <div className="flex items-center gap-2 text-2xl font-semibold">
//             <FaBurger />
//             <span className="italic font-extrabold">Foodry</span>
//           </div>
//         </div>

//         {/* DESKTOP NAV */}
//         <nav className="hidden md:flex items-center gap-10 font-semibold">
//           <Link to="/">HOME</Link>
//           <Link to="/new-products">SHOP</Link>
//           <Link to="/featured">FEATURED</Link>
//           <Link to="/pages">PAGES</Link>
//           <Link to="/blogs">BLOGS</Link>
//         </nav>

//         {/* LOGO */}
//         <div className="hidden md:flex items-center gap-2 text-4xl font-bold">
//           <FaBurger />
//           <span className="font-mono">Foodry</span>
//         </div>

//         {/* RIGHT ICONS */}
//         <div className="hidden md:flex items-center gap-6 text-xl">
//           <CiSearch />
//           <button onClick={() => setLoginOpen(true)}>
//             <CiUser />
//           </button>
//           <CiHeart />
//           <Link to="/cart" className="relative">
//             <CiShoppingBasket
//               className={cartItems.length ? "text-red-500" : ""}
//             />

//             {cartItems.length > 0 && (
//               <span className="absolute -top-2 -right-2 bg-red-500 text-xs w-5 h-5 rounded-full flex items-center justify-center">
//                 {cartItems.length}
//               </span>
//             )}
//           </Link>
//         </div>
//       </div>

//       {/* MOBILE MENU */}
//       {open && (
//         <div className="md:hidden bg-black/90 backdrop-blur-lg pb-4">
//           <nav className="flex flex-col gap-4 px-6 text-sm font-semibold">
//             <Link to="/">HOME</Link>
//             <Link to="/new-products">SHOP</Link>
//             <Link to="/featured">FEATURED</Link>
//             <Link to="/pages">PAGES</Link>
//             <Link to="/blogs">BLOGS</Link>
//           </nav>
//         </div>
//       )}

//       {/* LOGIN / REGISTER MODALS */}
//       <AnimatePresence>
//         {loginOpen && (
//           <Login
//             onClose={() => setLoginOpen(false)}
//             onRegisterOpen={() => {
//               setLoginOpen(false);
//               setRegisterOpen(true);
//             }}
//           />
//         )}

//         {registerOpen && (
//           <Register
//             onClose={() => setRegisterOpen(false)}
//             onLoginOpen={() => {
//               setRegisterOpen(false);
//               setLoginOpen(true);
//             }}
//           />
//         )}
//       </AnimatePresence>
//     </motion.header>
//   );
// }
// ================================================
import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useCart } from "../context/CartContext";

import { FaBurger } from "react-icons/fa6";
import { CiUser, CiSearch, CiHeart, CiShoppingBasket } from "react-icons/ci";
import { HiMenu, HiX } from "react-icons/hi";

import Login from "../pages/Login";
import Register from "../pages/Register";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const { cartItems } = useCart();
  const location = useLocation();

  // Home page → transparent, others → solid
  const forceSolidBg = location.pathname !== "/";

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.header
      initial={false}
      animate={{
        backgroundColor:
          scrolled || forceSolidBg ? "rgba(0,0,0,0.85)" : "rgba(0,0,0,0)",
        backdropFilter: scrolled || forceSolidBg ? "blur(12px)" : "blur(0px)",
      }}
      transition={{ duration: 0.35, ease: "easeInOut" }}
      className="fixed top-0 left-0 w-full z-50 text-white"
    >
      <div className="max-w-7xl mx-auto px-4 py-6 flex items-center justify-between overflow-x-hidden">
        {/* ================= MOBILE LEFT ================= */}
        <div className="flex items-center gap-4 md:hidden">
          <button onClick={() => setOpen(!open)} className="text-2xl shrink-0">
            {open ? <HiX /> : <HiMenu />}
          </button>

          {/* LOGO */}
          <div className="flex items-center gap-2 text-2xl font-semibold">
            <FaBurger />
            <span className="italic font-extrabold">Foodry</span>
          </div>
        </div>

        {/* ================= DESKTOP NAV ================= */}
        <nav className="hidden md:flex items-center gap-10 font-semibold">
          <Link to="/">HOME</Link>
          <Link to="/new-products">SHOP</Link>
          <Link to="/about">ABOUT US</Link>
          <Link to="/products">PRODUCTS</Link>
          <Link to="/blogs">BLOGS</Link>
        </nav>

        {/* ================= DESKTOP LOGO ================= */}
        <div className="hidden md:flex items-center gap-2 text-4xl font-bold">
          <FaBurger />
          <span className="font-mono">Foodry</span>
        </div>

        {/* ================= RIGHT ICONS (ALL DEVICES) ================= */}
        <div className="flex items-center gap-4 md:gap-6 text-xl shrink-0">
          <CiSearch />

          <button onClick={() => setLoginOpen(true)}>
            <CiUser />
          </button>

          <Link to="/wishlist">
            <CiHeart />
          </Link>

          <Link to="/cart" className="relative">
            <CiShoppingBasket
              className={cartItems.length ? "text-red-500" : ""}
            />

            {cartItems.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-xs w-5 h-5 rounded-full flex items-center justify-center">
                {cartItems.length}
              </span>
            )}
          </Link>
        </div>
      </div>

      {/* ================= MOBILE MENU ================= */}
      {open && (
        <div className="md:hidden bg-black/90 backdrop-blur-lg pb-4">
          <nav className="flex flex-col gap-4 px-6 text-sm font-semibold">
            <Link to="/" onClick={() => setOpen(false)}>
              HOME
            </Link>
            <Link to="/new-products" onClick={() => setOpen(false)}>
              SHOP
            </Link>
            <Link to="/featured" onClick={() => setOpen(false)}>
              FEATURED
            </Link>
            <Link to="/pages" onClick={() => setOpen(false)}>
              PAGES
            </Link>
            <Link to="/blogs" onClick={() => setOpen(false)}>
              BLOGS
            </Link>
          </nav>
        </div>
      )}

      {/* ================= LOGIN / REGISTER ================= */}
      <AnimatePresence>
        {loginOpen && (
          <Login
            onClose={() => setLoginOpen(false)}
            onRegisterOpen={() => {
              setLoginOpen(false);
              setRegisterOpen(true);
            }}
          />
        )}

        {registerOpen && (
          <Register
            onClose={() => setRegisterOpen(false)}
            onLoginOpen={() => {
              setRegisterOpen(false);
              setLoginOpen(true);
            }}
          />
        )}
      </AnimatePresence>
    </motion.header>
  );
}
