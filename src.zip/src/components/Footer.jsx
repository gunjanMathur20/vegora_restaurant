import React from "react";
import {
  FaTwitter,
  FaBasketballBall,
  FaBehance,
  FaInstagram,
  FaHamburger,
  FaCcVisa,
  FaCcMastercard,
  FaCcPaypal,
  FaCcDiscover,
} from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="w-full bg-white mt-5 pt-12">
      {/* Top Section */}
      <div className="max-w-7xl mx-auto px-2 grid grid-cols-1 md:grid-cols-4 gap-18">
        {/* Brand Section (Left Shift Added) */}
        <div className="md:-ml-10">
          <h1 className="text-5xl font-bold text-red-600 flex items-center gap-2">
            <FaHamburger size={32} /> Foodry
          </h1>

          <p className="mt-6 font-semibold text-black text-sm max-w-xs leading-relaxed">
            Sophisticated simplicity for the independent mind.
          </p>

          {/* Social Icons */}
          <div className="flex items-center gap-5 mt-7 text-gray-700 text-3xl">
            <FaTwitter className="hover:text-red-600 cursor-pointer" />
            <FaBasketballBall className="hover:text-red-600 cursor-pointer" />
            <FaBehance className="hover:text-red-600 cursor-pointer" />
            <FaInstagram className="hover:text-red-600 cursor-pointer" />
          </div>
        </div>

        {/* Help & Information */}
        <div>
          <h2 className="text-lg font-semibold mb-2">Help & Information</h2>
          <div className="w-12 h-[1px] bg-black mb-8"></div>

          <ul className="space-y-4 text-gray-700 text-sm">
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              About Us
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Privacy Policy
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Terms & Conditions
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Products Return
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Wholesale Policy
            </li>
          </ul>
        </div>

        {/* About Us */}
        <div>
          <h2 className="text-lg font-semibold mb-2">About Us</h2>
          <div className="w-12 h-[1px] bg-black mb-8"></div>

          <ul className="space-y-4 text-gray-700 text-sm">
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Pagination
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Terms & Conditions
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Contact
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Accessories
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Term of use
            </li>
          </ul>
        </div>

        {/* Categories */}
        <div>
          <h2 className="text-lg font-semibold mb-2">Categories</h2>
          <div className="w-12 h-[1px] bg-black mb-8"></div>

          <ul className="space-y-4 text-gray-700 text-sm">
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Help Center
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Address Store
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Privacy Policy
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Receivers & Amplifiers
            </li>
            <li className="cursor-pointer hover:text-red-600 font-semibold text-black">
              Clothings
            </li>
          </ul>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="mt-15 py-5 border-t border-gray-300">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center text-sm text-gray-600">
          <p className="text-center md:text-left">
            © Copyright 2020 |{" "}
            <span className="font-semibold">Foodry Store</span> By
            <span className="text-red-600"> Engo Theme.</span> Powered by
            Shopify.
          </p>

          {/* Payment Icons */}
          <div className="flex items-center gap-6 mt-4 md:mt-0 text-gray-800">
            <div className="flex items-center gap-1">
              <FaCcPaypal className="text-blue-600" size={24} />{" "}
              <span>PayPal</span>
            </div>
            <div className="flex items-center gap-1">
              <FaCcVisa className="text-blue-700" size={24} /> <span>VISA</span>
            </div>
            <div className="flex items-center gap-1">
              <FaCcMastercard className="text-red-600" size={24} />{" "}
              <span>MasterCard</span>
            </div>
            <div className="flex items-center gap-1">
              <FaCcDiscover className="text-orange-600" size={24} />{" "}
              <span>Discover</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
