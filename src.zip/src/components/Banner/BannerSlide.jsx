// import { motion } from "framer-motion";

// export default function BannerSlide({ slide }) {
//   const { textPosition } = slide;

//   return (
//     <motion.div
//       className="absolute inset-0 w-full h-full flex items-center"
//       initial={{
//         opacity: 0,
//         scale: 1.02,
//       }}
//       animate={{
//         opacity: 1,
//         scale: 1,
//       }}
//       exit={{
//         opacity: 0,
//         scale: 0.98,
//       }}
//       transition={{
//         duration: 0.45,
//         ease: "easeInOut",
//       }}
//       style={{
//         backgroundImage: `url(${slide.image})`,
//         backgroundSize: "cover",
//         backgroundPosition: "center",
//       }}
//     >
//       {/* DARK OVERLAY */}
//       <div className="absolute inset-0 bg-black/60" />

//       {/* CONTENT */}
//       <motion.div
//         initial={{ opacity: 0, y: 20 }}
//         animate={{ opacity: 1, y: 0 }}
//         exit={{ opacity: 0, y: -20 }}
//         transition={{
//           duration: 0.35,
//           delay: 0.1,
//           ease: "easeOut",
//         }}
//         className={`relative z-20 container mx-auto px-6 md:px-16 text-white max-w-2xl ${
//           textPosition === "right" ? "ml-auto text-right" : "mr-auto text-left"
//         }`}
//       >
//         <p className="uppercase tracking-[4px] text-sm mb-4">
//           {slide.subtitle}
//         </p>

//         <h1 className="text-4xl md:text-6xl font-serif font-bold">
//           {slide.title}
//         </h1>

//         <p className="mt-5 text-gray-200">
//           {slide.description}
//         </p>

//         <button className="mt-8 px-8 py-3 border border-white hover:bg-white hover:text-black transition">
//           {slide.button}
//         </button>
//       </motion.div>
//     </motion.div>
//   );
// }

import { motion } from "framer-motion";

/* 🔥 BACKGROUND SLIDE VARIANTS */
const bgVariants = {
  initial: (dir) => ({
    opacity: 0,
    x: dir === "right" ? 80 : -80,
  }),
  animate: {
    opacity: 1,
    x: 0,
  },
  exit: (dir) => ({
    opacity: 0,
    x: dir === "right" ? -80 : 80,
  }),
};

/*  TEXT VARIANTS (BOTTOM → TOP, SPRING) */
const textVariants = {
  initial: (isMobile) => ({
    opacity: 0,
    y: isMobile ? 25 : 60,
  }),
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 70,
      damping: 25,
      mass: 0.9,
    },
  },
  exit: {
    opacity: 0,
    y: -15,
    transition: {
      duration: 0.25,
      ease: "easeInOut",
    },
  },
};

/*  BUTTON VARIANTS (DELAYED) */
const buttonVariants = {
  initial: {
    opacity: 0,
    y: 20,
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      delay: 0.45, 
      duration: 0.3,
      ease: "easeOut",
    },
  },
};

export default function BannerSlide({ slide }) {
  const { textPosition } = slide;

  // ✅ SIMPLE MOBILE CHECK (NO LIBRARY)
  const isMobile = typeof window !== "undefined" && window.innerWidth < 768;

  return (
    <motion.div
      custom={textPosition}
      variants={bgVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{
        duration: 0.5,
        ease: "easeInOut",
      }}
      className="absolute inset-0 flex items-center"
      style={{
        backgroundImage: `url(${slide.image})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* OVERLAY */}
      <div className="absolute inset-0 bg-black/55" />

      {/* TEXT CONTENT */}
      <motion.div
        custom={isMobile}
        variants={textVariants}
        initial="initial"
        animate="animate"
        exit="exit"
        className={`relative z-20 container px-6 md:px-16 text-white max-w-2xl
          ${
            textPosition === "right"
              ? "md:ml-auto md:mr-24 md:text-right"
              : "md:mr-auto md:ml-24 md:text-left"
          }
        `}
      >
        <p className="uppercase tracking-[4px] text-sm mb-4">
          {slide.subtitle}
        </p>

        <h1 className="text-4xl md:text-6xl font-serif font-bold">
          {slide.title}
        </h1>

        <p className="mt-5 text-gray-200">{slide.description}</p>

        {/* BUTTON WITH EXTRA DELAY */}
        <motion.button
          variants={buttonVariants}
          initial="initial"
          animate="animate"
          className="mt-8 px-8 py-3 border border-white hover:bg-white hover:text-black transition"
        >
          {slide.button}
        </motion.button>
      </motion.div>
    </motion.div>
  );
}
