// import { useState } from "react";
// import { bannerData } from "../../data/bannerData";
// import BannerSlide from "./BannerSlide";
// import { HiChevronLeft, HiChevronRight } from "react-icons/hi";
// import { AnimatePresence } from "framer-motion";
// import { useSwipeable } from "react-swipeable";

// export default function Banner() {
//   const [index, setIndex] = useState(0);

//   const swipeHandlers = useSwipeable({
//     onSwipedLeft: () =>
//       setIndex((prev) => (prev + 1) % bannerData.length),
//     onSwipedRight: () =>
//       setIndex((prev) => (prev - 1 + bannerData.length) % bannerData.length),
//     trackMouse: true,
//   });

//   return (
//     <section
//       className="relative h-[85vh] md:h-[90vh] overflow-hidden bg-black"
//       {...swipeHandlers}
//     >
//       {/* SLIDES */}
//       <AnimatePresence initial={false}>
//         <BannerSlide
//           key={bannerData[index].id}
//           slide={bannerData[index]}
//         />
//       </AnimatePresence>

//       {/* LEFT ARROW */}
//       <button
//         onClick={() =>
//           setIndex((prev) => (prev - 1 + bannerData.length) % bannerData.length)
//         }
//         className="absolute left-4 top-1/2 -translate-y-1/2 text-white text-3xl z-30"
//       >
//         <HiChevronLeft />
//       </button>

//       {/* RIGHT ARROW */}
//       <button
//         onClick={() =>
//           setIndex((prev) => (prev + 1) % bannerData.length)
//         }
//         className="absolute right-4 top-1/2 -translate-y-1/2 text-white text-3xl z-30"
//       >
//         <HiChevronRight />
//       </button>

//       {/* DOTS */}
//       <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-3 z-30">
//         {bannerData.map((_, i) => (
//           <span
//             key={i}
//             onClick={() => setIndex(i)}
//             className={`w-3 h-3 rounded-full cursor-pointer ${
//               i === index ? "bg-white" : "bg-white/40"
//             }`}
//           />
//         ))}
//       </div>
//     </section>
//   );
// }

import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { HiChevronLeft, HiChevronRight } from "react-icons/hi";
import { useSwipeable } from "react-swipeable";

import BannerSlide from "./BannerSlide";
import { bannerData } from "../../data/bannerData";

export default function Banner() {
  const [index, setIndex] = useState(0);

  const swipeHandlers = useSwipeable({
    onSwipedLeft: () =>
      setIndex((prev) => (prev + 1) % bannerData.length),
    onSwipedRight: () =>
      setIndex((prev) => (prev - 1 + bannerData.length) % bannerData.length),
    trackMouse: true,
  });

  return (
    <section
      className="relative h-screen overflow-hidden bg-black"
      {...swipeHandlers}
    >
      {/* SLIDES */}
      <AnimatePresence initial={false}>
        <BannerSlide
          key={bannerData[index].id}
          slide={bannerData[index]}
        />
      </AnimatePresence>

      {/* LEFT ARROW */}
      <button
        onClick={() =>
          setIndex((prev) => (prev - 1 + bannerData.length) % bannerData.length)
        }
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 text-white text-3xl"
      >
        <HiChevronLeft />
      </button>

      {/* RIGHT ARROW */}
      <button
        onClick={() =>
          setIndex((prev) => (prev + 1) % bannerData.length)
        }
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 text-white text-3xl"
      >
        <HiChevronRight />
      </button>

      {/* DOTS */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-3 z-30">
        {bannerData.map((_, i) => (
          <span
            key={i}
            onClick={() => setIndex(i)}
            className={`w-3 h-3 rounded-full cursor-pointer ${
              i === index ? "bg-white" : "bg-white/40"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
