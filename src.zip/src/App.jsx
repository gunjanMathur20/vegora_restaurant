import Header from "./components/Header";
import Footer from "./components/Footer";
import PageTransition from "./components/PageTransition";

import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";

// IMPORT YOUR PAGES
import Home from "./pages/Home";
import Instagram from "./pages/Instagram";
import NewProducts from "./pages/NewProducts";
import Login from "./pages/Login";
import Register from "./pages/Register";
import CartPage from "./pages/CartPage";
import WishlistPage from "./pages/WishlistPage";
import About from "./pages/About";

function AnimatedRoutes() {
  const location = useLocation();

  return (
    <PageTransition key={location.pathname}>
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Home />} />
        <Route path="/instagram" element={<Instagram />} />
        <Route path="/new-products" element={<NewProducts />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/wishlist" element={<WishlistPage />} />
        <Route path="/about" element={<About />} />
        

        {/* Add more routes */}
      </Routes>
    </PageTransition>
  );
}

export default function App() {
  return (
    <Router>
      <Header />
      <AnimatedRoutes />
      <Footer />
    </Router>
  );
}
