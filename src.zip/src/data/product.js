const products = [
  {
    id: 1,
    name: "Pizza",
    price: 10,
    oldPrice: null,
    discount: null,
    image: "/images/pizza.webp",
    sale: true,
    dealEnd: Date.now() + 86400000,
  },
  {
    id: 2,
    name: "The Deli Taco Soft",
    price: 15,
    oldPrice: 18,
    discount: 17,
    image: "/images/deli-taco.webp",
    sale: true,
    dealEnd: Date.now() + 86400000,
  },
  {
    id: 3,
    name: "French Fries Video",
    price: 6,
    image: "/images/french-fries.webp",
    sale: true,
    dealEnd: Date.now() + 86400000,
  },
  {
    id: 4,
    name: "Double Classic Burger",
    price: 8,
    oldPrice: 15,
    image: "/images/classic-burger.webp",
    sale: true,
    dealEnd: Date.now() + 86400000,
  },
];

export default products;
