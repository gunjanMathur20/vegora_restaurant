import slide1 from "../assets/bannerSlide01.webp";
import slide2 from "../assets/bannerSlide02.webp";

export const bannerData = [
  {
    id: 1,
    title: "Best Burger & Delicious",
    subtitle: " NEED IT NOW",
    description: "Contemporary, minimal and beautifully iconic.",
    button: "SHOP NOW",
    image: slide1,
    textPosition: "right",
  },
  {
    id: 2,
    title: "Best Burger & Delicious",
    subtitle: "DON'T MISS TODAY'S DEALS",
    description: "Here to bring your lifestyle to the next level.",
    button: "BUY NOW",
    image: slide2,
    textPosition: "left",
  },
];
